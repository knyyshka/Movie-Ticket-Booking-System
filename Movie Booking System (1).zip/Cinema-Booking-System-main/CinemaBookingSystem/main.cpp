#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <limits>
#include "Seat.cpp"
#include "Screen.cpp"
#include "Movie.cpp"
#include "ShowSeat.cpp"
#include "Show.cpp"
#include "Cinema.cpp"
#include "Customer.cpp"
#include "Payment.cpp"
#include "UpiPayment.cpp"
#include "CardPayment.cpp"
#include "CashPayment.cpp"
#include "Booking.cpp"
#include "BookingService.cpp"
#include "TicketPrinter.cpp"

using namespace std;

vector<string> parseSeats(const string& input) {
    vector<string> seats;
    stringstream ss(input);
    string seat;
    while (getline(ss, seat, ',')) {
        size_t start = seat.find_first_not_of(" \t\r\n");
        size_t end = seat.find_last_not_of(" \t\r\n");
        if (start != string::npos && end != string::npos) {
            seats.push_back(seat.substr(start, end - start + 1));
        }
    }
    return seats;
}

int main() {
    Cinema cinema("HJCINEMA");
    
    Screen screen1("Screen-1");
    screen1.addSeat(Seat("A1", "SILVER"));
    screen1.addSeat(Seat("A2", "SILVER"));
    screen1.addSeat(Seat("A3", "SILVER"));
    screen1.addSeat(Seat("A4", "SILVER"));
    screen1.addSeat(Seat("B1", "GOLD"));
    screen1.addSeat(Seat("B2", "GOLD"));
    screen1.addSeat(Seat("B3", "GOLD"));
    screen1.addSeat(Seat("C1", "PLATINUM"));
    screen1.addSeat(Seat("C2", "PLATINUM"));

    Screen screen2("Screen-2");
    screen2.addSeat(Seat("A1", "SILVER"));
    screen2.addSeat(Seat("A2", "SILVER"));
    screen2.addSeat(Seat("B1", "GOLD"));
    screen2.addSeat(Seat("B2", "GOLD"));
    screen2.addSeat(Seat("C1", "PLATINUM"));

    cinema.addScreen(screen1);
    cinema.addScreen(screen2);

    Movie toxicMovie("TOXIC", "HINDI", 200);
    Movie mirzapurMovie("MIRZAPUR THE MOVIE" , "HINDI", 180);
    Movie hanumanMovie("HANUMAN ANSH", "HINDI", 150);
    Movie spiderMovie("SPIDER MAN BRAND NEW DAY", "ENGLISH", 145);
    Movie odysseyMovie("THE ODYSSEY MOVIE", "ENGLISH", 175);

    Show morningShow(101, &toxicMovie, &screen1, "09:00 AM");
    Show noonShow(102, &mirzapurMovie, &screen1, "01:00 PM");
    Show eveningShow(103, &hanumanMovie, &screen1, "04:00 PM");
    Show nightShow1(104, &spiderMovie, &screen2, "06:00 PM");
    Show nightShow2(105, &odysseyMovie, &screen1, "07:00 PM");

    vector<Movie> movies = {toxicMovie, mirzapurMovie, hanumanMovie, spiderMovie, odysseyMovie};
    vector<Show> shows = {morningShow, noonShow, eveningShow, nightShow1, nightShow2};

    BookingService service(&cinema);
    vector<Booking*> myTickets;

    int choice;
    do {
        cout << "\n===== MOVIE TICKET BOOKING =====BY HIMANSHU JAYARA ====\n";
        cout << "1. Movies   2. Book   3. Cancel   4. My tickets   0. Exit\n";
        cout << "Choose: ";
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "[Error] Invalid input. Please enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1: {
                cout << "\n--- AVAILABLE MOVIES ---\n";
                for (size_t i = 0; i < movies.size(); ++i) {
                    cout << "[" << i + 1 << "] " << movies[i].getTitle() 
                         << "\t" << movies[i].getLanguage() 
                         << " " << movies[i].getDurationMinutes() << " min\n";
                }
                break;
            }
            case 2: {
                cout << "\n--- SELECT A MOVIE ---\n";
                for (size_t i = 0; i < movies.size(); ++i) {
                    cout << "[" << i + 1 << "] " << movies[i].getTitle() 
                         << "\t" << movies[i].getLanguage() 
                         << " " << movies[i].getDurationMinutes() << " min\n";
                }
                cout << "\nChoose movie: ";
                int movieChoice;
                if (!(cin >> movieChoice) || movieChoice < 1 || movieChoice > static_cast<int>(movies.size())) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "[Error] Invalid movie choice! Operation aborted.\n";
                    break;
                }

                Movie* selectedMovie = &movies[movieChoice - 1];

                vector<Show*> availableShows;
                for (auto& show : shows) {
                    if (show.getMovie()->getTitle() == selectedMovie->getTitle()) {
                        availableShows.push_back(&show);
                    }
                }
                if (availableShows.empty()) {
                    cout << "[Error] No shows available for this movie!\n";
                    break;
                }
                cout << "\n--- AVAILABLE SHOWS FOR " << selectedMovie->getTitle() << " ---\n";
                for (size_t i = 0; i < availableShows.size(); ++i) {
                    cout << "[" << i + 1 << "] Show Time: " << availableShows[i]->getShowTime() << "\n";
                }
                cout << "Choose show: ";
                int showChoice;
                if (!(cin >> showChoice) || showChoice < 1 || showChoice > static_cast<int>(availableShows.size())) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "[Error] Invalid show choice! Operation aborted.\n";
                    break;
                }

                Show* selectedShow = availableShows[showChoice - 1];
                cout << "\nShow Time: " << selectedShow->getShowTime() 
                     << "  |  Movie: " << selectedShow->getMovie()->getTitle() << "\n";
                
                cout << "SILVER    ";
                for (auto& ss : selectedShow->getShowSeats()) {
                    if (ss.getSeat().getCategory() == "SILVER") {
                        cout << ss.getSeat().getSeatNumber() 
                             << (ss.isBooked() ? "[X] " : "[ ] ");
                    }
                }
                cout << "\nGOLD      ";
                for (auto& ss : selectedShow->getShowSeats()) {
                    if (ss.getSeat().getCategory() == "GOLD") {
                        cout << ss.getSeat().getSeatNumber() 
                             << (ss.isBooked() ? "[X] " : "[ ] ");
                    }
                }
                cout << "\nPLATINUM  ";
                for (auto& ss : selectedShow->getShowSeats()) {
                    if (ss.getSeat().getCategory() == "PLATINUM") {
                        cout << ss.getSeat().getSeatNumber() 
                             << (ss.isBooked() ? "[X] " : "[ ] ");
                    }
                }
                cout << "\n\n( [ ] = available   [X] = booked )\n\n";
                cout << "Seats (e.g. A1,B2): ";
                string seatsInput;
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                getline(cin, seatsInput);

                vector<string> chosenSeats = parseSeats(seatsInput);
                if (chosenSeats.empty()) {
                    cout << "[Error] No valid seats specified! Operation aborted.\n";
                    break;
                }

                Customer customer("Himanshu", "9876543210");
                Booking* booking = service.createBooking(customer, selectedShow, chosenSeats);
                if (!booking) {
                    cout << "[Error] Seat reservation failed.\n";
                    break;
                }

                double total = 0;
                for (auto* ss : booking->getBookedSeats()) {
                    double price = (ss->getSeat().getCategory() == "PLATINUM") ? 350 :
                                  (ss->getSeat().getCategory() == "GOLD") ? 250 : 150;
                    cout << ss->getSeat().getSeatNumber() << " " 
                         << ss->getSeat().getCategory() << " Rs." << price << "\n";
                    total += price;
                }
                cout << "TOTAL          Rs." << total << "\n\n";

                cout << "Pay by: 1.UPI   2.Card   3.Cash > ";
                int payChoice;
                if (!(cin >> payChoice) || payChoice < 1 || payChoice > 3) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "[Error] Invalid payment option! Booking aborted.\n";
                    service.cancelBooking(booking);
                    break;
                }

                Payment* payment = nullptr;
                if (payChoice == 1) payment = new UpiPayment("user@upi");
                else if (payChoice == 2) payment = new CardPayment("4111-XXXX-XXXX-1111");
                else payment = new CashPayment();

                if (service.processPayment(booking, payment)) {
                    myTickets.push_back(booking);
                    TicketPrinter::printTicket(booking);
                } else {
                    service.cancelBooking(booking);
                }
                delete payment;
                break;
            }

            case 3: {
                if (myTickets.empty()) {
                    cout << "\nNo bookings found to cancel.\n";
                    break;
                }
                cout << "\n--- CANCEL BOOKING ---\n";
                cout << "Enter Booking ID: ";
                int bId;
                if (!(cin >> bId)) {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "[Error] Invalid Booking ID format.\n";
                    break;
                }

                bool found = false;
                for (auto it = myTickets.begin(); it != myTickets.end(); ++it) {
                    if ((*it)->getBookingId() == bId) {
                        service.cancelBooking(*it);
                        myTickets.erase(it);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "Booking ID not found.\n";
                }
                break;
            }

            case 4: {
                cout << "\n--- MY TICKETS ---\n";
                if (myTickets.empty()) {
                    cout << "No tickets booked yet.\n";
                } else {
                    for (auto* b : myTickets) {
                        TicketPrinter::printTicket(b);
                    }
                }
                break;
            }

            case 0:
                cout << "\nExiting System. Goodbye!\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
                break;
        }

    } while (choice != 0);

    for (auto* b : myTickets) delete b;

    return 0;
}